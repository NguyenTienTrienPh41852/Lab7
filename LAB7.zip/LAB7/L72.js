import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button } from 'react-native';
import { CREATE_EMAIL, FIREBASE_AUTH,SIGNIN_EMAIL } from './firebaseconfig'; // Import firebase auth instance

const AuthScreen = () => {
  const [initializing, setInitializing] = useState(true);
  const [user, setUser] = useState(null);
  const [userInput, setUserInput] = useState({ email: '', password: '' });

  useEffect(() => {
    const unsubscribe = FIREBASE_AUTH.onAuthStateChanged(currentUser => {
      setUser(currentUser);
      if (initializing) {
        setInitializing(false);
      }
    });

    return unsubscribe;
  }, []);

  const onSignUpWithPassword = async () => {
    try {
      await CREATE_EMAIL(userInput.email, userInput.password);
      console.log('User signed up successfully.');
    } catch (error) {
      console.error('Error signing up:', error);
    }
  };

  const onSignInWithPassword = async () => {
    try {
      await SIGNIN_EMAIL(userInput.email, userInput.password);
      console.log('User signed in successfully.');
    } catch (error) {
      console.error('Error signing in:', error);
    }
  };

  const onSignOut = async () => {
    try {
      await FIREBASE_AUTH.signOut();
      console.log('User signed out successfully.');
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  if (initializing) return null;

  if (!user) {
    return (
      <View>
        <Text>Email:</Text>
        <TextInput
          placeholder="Enter your email"
          value={userInput.email}
          onChangeText={text => setUserInput({ ...userInput, email: text })}
        />
        <Text>Password:</Text>
        <TextInput
          placeholder="Enter your password"
          secureTextEntry={true}
          value={userInput.password}
          onChangeText={text => setUserInput({ ...userInput, password: text })}
        />
        <Button title="Sign Up" onPress={onSignUpWithPassword} />
        <Button title="Sign In" onPress={onSignInWithPassword} />
      </View>
    );
  }

  return (
    <View>
      <Text>Welcome, {user.email}</Text>
      <Button title="Sign Out" onPress={onSignOut} />
    </View>
  );
};

export default AuthScreen;
