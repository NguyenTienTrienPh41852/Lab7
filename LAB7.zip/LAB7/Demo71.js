import { Button, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native'
import React, { useState } from 'react'
import {collection,addDoc} from 'firebase/firestore'
import { FIRESTORE_DB } from './firebaseconfig'
const Demo71 = () => {
  const [text, setText] = useState('');
  const handleInsert = async()=>{
    
    try {
      const tailieu = await addDoc(collection(FIRESTORE_DB,'SinhVien'),{
        text:text
      })
      console.log("tai lieu duoc ghi voi id=",tailieu.id)
      console.log('id')
      setText('')
    } catch (error) {
      console.log("Loi ghi dl"+error)
    }
  }
  return (
    <View>
      <TextInput placeholder='Nhập tên sinh viên' value={text} onChangeText={setText}/>
      <TouchableOpacity onPress={handleInsert}>
        <Text>Thêm</Text>
      </TouchableOpacity>
    </View>
  )
}

export default Demo71

const styles = StyleSheet.create({})