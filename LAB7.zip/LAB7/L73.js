// L73.js
import React, { useState } from 'react';
import { StyleSheet, Text, View, Button } from 'react-native';
import { FIREBASE_AUTH, SIGNIN_GOOGLE } from './firebaseconfig';

const L73 = () => {
    const [loggedIn, setLoggedIn] = useState(false);

    const onSignInWithRedirect = async () => {
        try {
            const result =  await SIGNIN_GOOGLE();
            setLoggedIn(true); // Đặt trạng thái đăng nhập thành true
            console.log('signin success'+ result)
        } catch (error) {
            console.error('Error signing in with Google:', error);
        }
    }
    console.log(loggedIn)
    const onSignOut = async () => {
        try {
            await FIREBASE_AUTH.signOut(); // Sử dụng await để đảm bảo đăng xuất hoàn tất trước khi cập nhật trạng thái
            setLoggedIn(false); // Đặt trạng thái đăng nhập thành false
        } catch (error) {
            console.error('Error signing out with Google:', error);
        }
    }

    return (
        <View style={styles.container}>
            <Text>Đăng nhập bằng Google</Text>
            {loggedIn ? ( // Sử dụng điều kiện hiển thị để chọn nút đăng nhập hoặc đăng xuất
                <Button title="Sign out" onPress={onSignOut} />
            ) : (
                <Button title="Sign in with Google" onPress={onSignInWithRedirect} />
            )}
        </View>
    );
}

export default L73;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
});
